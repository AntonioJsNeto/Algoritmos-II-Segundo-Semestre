package Retangulo;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);
    public static void main(String [] args){
        Retangulo retangulo = new Retangulo();
        System.out.println("Informe a altura do retangulo: ");
        retangulo.setAltura(sc.nextDouble());
        System.out.println("Informe a base do retangulo: ");
        retangulo.setBase(sc.nextDouble());

        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("A area do retangulo eh: " + df.format(retangulo.area()));
        System.out.println("O perimetro do retangulo eh: " + df.format(retangulo.perimetro()));
    }
}
