package Pedido;

public class Pedido {
    private double valor;
    private int parcelas;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getParcelas() {
        return parcelas;
    }

    public void setParcelas(int parcelas) {
        this.parcelas = parcelas;
    }

    public double total() {
        double total = 0;
        if (parcelas > 1) {
            total =valor * (1 + juros());
            return total;
        }else {
            return total = valor;
        }
    }

    private double juros() {
            double juros = 0.01;
            double jur = juros * Math.pow((1 + juros), parcelas);
            return jur;
    }
}
