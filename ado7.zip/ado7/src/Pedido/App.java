package Pedido;

import java.util.Scanner;
import java.text.DecimalFormat;

public class App {
    static Scanner sc = new Scanner(System.in);
    public static void main(String [] args){
        Pedido pedido = new Pedido();

        System.out.println("INFORME O VALOR DO PEDIDO: ");
        pedido.setValor(sc.nextDouble());
        System.out.println("INFORME A QUANTIDADE DE PARCELAS: ");
        pedido.setParcelas(sc.nextInt());

        DecimalFormat df = new DecimalFormat("0.00");

        if (pedido.getParcelas() == 1){
            System.out.println("O PEDIDO FICOU POR: " + df.format(pedido.total()));
        }else if(pedido.getParcelas() > 1){
            System.out.println("O PEDIDO FICOU POR: " + df.format(pedido.total()));
            System.out.println("O VALOR DAS PARCELAS FICOU DE: " + df.format(pedido.total() / pedido.getParcelas()));
        }
    }
}
