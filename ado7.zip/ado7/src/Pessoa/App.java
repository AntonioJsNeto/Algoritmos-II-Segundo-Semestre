package Pessoa;

import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);
    public static void main (String [] args){
        Pessoa pessoa = new Pessoa();

        System.out.println("QUAL O NOME COMPLETO: ");
        pessoa.setNomeCompleto(sc.nextLine());
        System.out.println("QUAL O ANO DE NASCIMENTO: ");
        pessoa.setAnoNasc(sc.nextInt());

        System.out.println("O USUARIO: " + pessoa.primeiroNome() + " " + pessoa.ultimoNome()
        + " tem " + pessoa.idade() + " anos!");
    }
}
