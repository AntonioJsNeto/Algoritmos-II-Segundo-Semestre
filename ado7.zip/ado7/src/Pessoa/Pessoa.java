package Pessoa;

public class Pessoa {
    private String nomeCompleto;
    private int anoNasc;

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public int getAnoNasc() {
        return anoNasc;
    }

    public void setAnoNasc(int anoNasc) {
        this.anoNasc = anoNasc;
    }

    public int idade() {
        int idade = 2023 - this.anoNasc;
        return idade;
    }

    public String primeiroNome() {
        String[] divisao = this.nomeCompleto.split(" ");
        String primeiroNome = " ";
        if (divisao.length > 0) {
            primeiroNome = divisao[0];
        }
        return primeiroNome;
    }

    public String ultimoNome() {
        String[] divisao = this.nomeCompleto.split(" ");
        String ultimoNome = " ";
        if (divisao.length > 0) {
            divisao[0] = divisao[divisao.length - 1];
            ultimoNome = divisao[0];
        }
        return ultimoNome;
    }
}

