package TrinaguloRetangulo;

public class TrianguloRetangulo {
    private double catetoOposto;
    private double catetoAdjacente;

    public double getCatetoOposto() {
        return catetoOposto;
    }

    public void setCatetoOposto(double catetoOposto) {
        this.catetoOposto = catetoOposto;
    }

    public double getCatetoAdjacente() {
        return catetoAdjacente;
    }

    public void setCatetoAdjacente(double catetoAdjacente) {
        this.catetoAdjacente = catetoAdjacente;
    }

    public double area(){
        double area = (this.catetoOposto * this.catetoAdjacente) / 2;
        return area;
    }

    public double hipotenusa(){
        double hipotenusa = Math.sqrt(Math.pow(catetoAdjacente,2) + Math.pow(catetoOposto,2));
        return hipotenusa;
    }

    public double perimetro(){
        double perimetro = hipotenusa() + this.catetoOposto + this.catetoAdjacente;
        return perimetro;
    }
}
