package TrinaguloRetangulo;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);
    public static void main(String [] args){
        TrianguloRetangulo tr = new TrianguloRetangulo();


        System.out.println("INFORME O CATETO OPOSTO: ");
        tr.setCatetoOposto(sc.nextDouble());
        System.out.println("INFORME O CATETO ADJACENTE: ");
        tr.setCatetoAdjacente(sc.nextDouble());

        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("A AREA DO TRIANGULO RETANGULO EH: " + df.format(tr.area()));
        System.out.println("O PERIMETRO DO TRIANGULO RETANGULO EH: " + df.format(tr.perimetro()));
        System.out.println("A HIPOTENUSA DO TRIANGULO RETANGULO EH: " + df.format(tr.hipotenusa()));
    }
}
