import java.util.Scanner;

public class UI {
    static Scanner ler = new Scanner(System.in);

    public void apresentarPrograma(){
        escrever("### PROGRAMA LISTA DE TAREFAS ###\n");
    }

    public int menu(){
        escrever("\n que deseja fazer?");
        escrever("1. Adicionar Tarefa");
        escrever("2. Remover Tarefa");
        escrever("3. Exibir lista");
        escrever("0. Sair");
        return ler.nextInt();
    }

    public void escrever(String msg,Object... values){
        System.out.printf(msg + "\n", values);
    }

    public double pedirDouble(String msg, Object... values) {
        System.out.printf(msg, values);
        double valor = ler.nextDouble();
        return valor;
    }

    public String pedirTexto(String msg, Object... values){
        System.out.printf(msg, values);
        ler.nextLine();
        String valor = ler.nextLine();
        return valor;
    }

    public String pedirTexto2(String msg, Object... values){
        System.out.printf(msg, values);
        String valor = ler.nextLine();
        return valor;
    }

    public int pedirInt(String msg, Object... values){
        System.out.printf(msg, values);
        int valor = ler.nextInt();
        return valor;
    }
    public void pularLinha(){
        System.out.println();
    }
}
