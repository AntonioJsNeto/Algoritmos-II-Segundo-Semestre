import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner ler = new Scanner(System.in);

        UI tela = new UI();
        tela.apresentarPrograma();

        ListaTarefas list = new ListaTarefas();
        list.setTitulo(tela.pedirTexto2("\nTitulo da lista:\n"));

        int opcao;
        do{
            opcao = tela.menu();
            switch (opcao){
                case 1:
                    list.adicionar(tela.pedirTexto("Informe a tarefa: \n"));
                    tela.escrever(">> Tarefa adicionada!");
                    break;

                case 2:
                    list.remover((tela.pedirInt("\nInforme a posicao:\n")));
                    break;

                case 3:
                    list.printarLista();
                    break;
            }
        }while (opcao != 0);
    }
}