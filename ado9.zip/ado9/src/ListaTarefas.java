import java.util.ArrayList;

public class ListaTarefas {
    private String titulo;
    private ArrayList<String> itens = new ArrayList<String>();

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void adicionar(String novoItem){
        itens.add(novoItem);
    }

    public void remover(int posicao){
        itens.remove(posicao - 1);
    }

    public void printarLista(){
        System.out.printf("\n\n---- Lista %s ----\n", this.titulo);
        for (int i = 0; i < this.itens.size(); i++) {
            System.out.printf("%d. %s \n", i+1, this.itens.get(i));
        }
    }
}