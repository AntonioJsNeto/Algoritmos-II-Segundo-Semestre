
package media;

public class NotasAluno {
   private Aluno aluno;
   private NotasDisciplinas[] disciplinas;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public NotasDisciplinas[] getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(NotasDisciplinas[] disciplinas) {
        this.disciplinas = disciplinas;
    }
   
   
}
