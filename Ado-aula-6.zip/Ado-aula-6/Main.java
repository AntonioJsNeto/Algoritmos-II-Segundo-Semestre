package media;

public class Main{
        public static void main(String[] args) throws Exception {

            UL tela = new UL();

            Aluno aluno = new Aluno();
            aluno.setNome(tela.pedirTexto("Nome: "));
            aluno.setChamada(tela.pedirInt("Chamada: "));
            aluno.setCurso(tela.pedirTexto("Curso: "));
            aluno.setTurma(tela.pedirTexto("Turma: "));

            int qtd = tela.pedirInt("Qtd. disciplinas: ");

            NotasDisciplinas[] disciplinas = new NotasDisciplinas[qtd];

            for (int i = 0; i < disciplinas.length; i++) {
                NotasDisciplinas nota = new NotasDisciplinas();
                nota.setDisciplina(tela.pedirTexto("Disciplina " + (i + 1)));
                nota.setMedia(tela.pedirDouble("Média: "));
                nota.setFaltas(tela.pedirInt("Faltas: "));
                disciplinas[i] = nota;

                tela.escrever("----");
            }

            NotasAluno notasAluno = new NotasAluno();
            notasAluno.setAluno(aluno);
            notasAluno.setDisciplinas(disciplinas);

            Boletim boletim = new Boletim();
            Resultado res = boletim.avaliar(notasAluno);

            tela.exibirResultado(res);


        }

    }
