package media;

import java.util.*;
public class UL {
    static  Scanner sc = new Scanner (System.in);

    public void apresentarPrograma() {
        escrever("##### PROGRAMA DA MÉDIA #####\n");
    }

    public void escrever(String msg, Object... values) {
        System.out.printf(msg +"\n", values);
    }

    public double pedirDouble(String msg, Object... values) {
        System.out.printf(msg , values);
        double valor = sc.nextDouble();
        return valor;
    }

    public int pedirInt(String msg, Object... values) {
        System.out.printf(msg , values);
        int valor = sc.nextInt();
        return valor;
    }

    public String pedirTexto(String msg, Object... values) {
        System.out.printf(msg , values);
        String valor = sc.next();
        return valor;
    }

    public void pularLinha() {
        System.out.println();
    }



    public void exibirResultado(Resultado res) {
        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("     BOLETIM GERADO!");
        escrever("=========================");

        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("         DISCIPLINAS");
        escrever("=========================");

        for (NotasDisciplinas item : res.getDisciplinas()) {
            escrever("%s, Média: %.1f, Faltas: %d",
                    item.getDisciplina(),
                    item.getMedia(),
                    item.getFaltas());
        }

        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("        SITUAÇÃO");
        escrever("=========================");
        escrever("  Qtd. Aprovações: %d ", res.getQtdAprovacoes());
        escrever(" Qtd. Reprovações: %d ", res.getQtdReprovacoes());
        escrever("   Situação Final: %s ", res.getSituacao());


        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("          FIM");
        escrever("=========================");
        pularLinha();
        pularLinha();
        pularLinha();
    }
}