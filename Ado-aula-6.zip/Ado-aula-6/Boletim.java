package media;

public class Boletim {
    public Resultado avaliar(NotasAluno notasAluno){
        Resultado result = new Resultado ();
        int reprovacoes = 0;
        int aprovacoes = 0;
        
        for(NotasDisciplinas item : notasAluno.getDisciplinas()){
            String veri = verificarSituacao(item.getMedia(), item.getFaltas());
            if(veri.equals ("DP por Nota") || veri.equals("DP por Falta")){
                reprovacoes++;
            }else{
                aprovacoes++;
            } 
            
        }
        result.setAluno(notasAluno.getAluno());
        result.setDisciplinas(notasAluno.getDisciplinas());
        result.setQtdAprovacoes(aprovacoes);
        result.setQtdReprovacoes(reprovacoes);
        result.setSituacao((reprovacoes > 0)? "REPROVADO!" : "APROVADO!");
        
        return result;
    }
    
    private String verificarSituacao(double media, int faltas){
        String sit ="";
        
        if(media < 6){
            sit = "DP por Nota";
        }else if (faltas > 4){
            sit = "DP por Falta";
        }else{
            sit = "Aprovado";
        }
        
        return sit;
    }
}