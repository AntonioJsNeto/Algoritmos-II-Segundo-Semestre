package media;

public class Aluno {
    private String nome;
    private int chamada;
    private String curso;
    private String turma;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getChamada() {
        return chamada;
    }

    public void setChamada(int chamada) {
        this.chamada = chamada;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }
    
}