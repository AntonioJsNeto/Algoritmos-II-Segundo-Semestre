
package media;

/**
 *
 * @author antonio.jsneto9
 */
public class Resultado {
    private Aluno aluno;
    private NotasDisciplinas[] disciplinas;
    
    private String situacao;
    private int qtdAprovacoes;
    private int qtdReprovacoes;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public NotasDisciplinas[] getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(NotasDisciplinas[] disciplinas) {
        this.disciplinas = disciplinas;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public int getQtdAprovacoes() {
        return qtdAprovacoes;
    }

    public void setQtdAprovacoes(int qtdAprovacoes) {
        this.qtdAprovacoes = qtdAprovacoes;
    }

    public int getQtdReprovacoes() {
        return qtdReprovacoes;
    }

    public void setQtdReprovacoes(int qtdReprovacoes) {
        this.qtdReprovacoes = qtdReprovacoes;
    }
    
    
}