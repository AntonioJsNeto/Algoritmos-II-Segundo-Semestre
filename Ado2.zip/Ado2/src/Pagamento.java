import java.math.*;
public class Pagamento {
    public double calcularTotal(Compra compra){
            double valor = compra.getTotal() * Math.pow(1 + buscarTaxas(compra.getParcelas()), compra.getParcelas());
    return valor;
}
    public double calcularParcelas (double totalFinal, int parcelas){
        return totalFinal / parcelas;
    }

    private double buscarTaxas(int parcelas){
            double jurosBaixos = 0.03;
            double jurosMedios = 0.05;
            double jurosAltos = 0.10;
            if (parcelas >= 1 && parcelas <= 3){
                return jurosBaixos;
            } else if(parcelas > 3 && parcelas <= 12)
            {
                return jurosMedios;
            }
            else {
                return jurosAltos;
            }
    }
}
