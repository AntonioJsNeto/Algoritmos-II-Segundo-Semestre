import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Compra compra = new Compra();
        Pagamento pag = new Pagamento();

        System.out.println("Digite o valor total da compra: ");
        compra.setTotal(sc.nextDouble());
        System.out.println("Digite a quantidade de parcelas: ");
        compra.setParcelas(sc.nextInt());

        double totalFinal = pag.calcularTotal(compra);
        double valorParcelas = pag.calcularParcelas(totalFinal, compra.getParcelas());

        System.out.println("Valor final: " + totalFinal);
        System.out.println("Valor das Parcelas:n" + valorParcelas);
    }
}