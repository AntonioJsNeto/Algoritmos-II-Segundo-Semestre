
package Pizzaria;

public class Pagamento {
    
    public Comprovante faturarPedido(Pedido pedido){
       double calc = this.calcularTotal(pedido);
       int codigo = this.gerarCodigo();

        Comprovante compr = new Comprovante();
        compr.setCliente(pedido.getCliente());
        compr.setItens(pedido.getItens());
        compr.setCodigo(codigo);
        compr.setTotal(calc);
       
       return compr;
    }
    
    private double calcularTotal (Pedido pedido){
        double total = 0;
        for(Item i : pedido.getItens()){
            total += i.getPreco();
        }
        return total;
    }
    
    private int gerarCodigo (){
        int cod = (int) (Math.random()*999);
        return cod;
    }
}
