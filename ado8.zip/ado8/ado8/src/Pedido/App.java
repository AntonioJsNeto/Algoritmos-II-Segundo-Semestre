package Pedido;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);

    public static void main(String [] args){
        System.out.println("Informe o valor do pedido: ");
        double valor = sc.nextDouble();;
        System.out.println("INFORME A QUANTIDADE DE PARCELAS: ");
        int parcelas = sc.nextInt();;

        Pedido pedido = new Pedido(valor, parcelas);
        DecimalFormat df = new DecimalFormat("0.00");

        double total = pedido.getTotal();
        double juros = pedido.getJuros();

        if (parcelas == 1) {
            System.out.println("O pedido ficou por: " + df.format(total));
        }
    }
}
