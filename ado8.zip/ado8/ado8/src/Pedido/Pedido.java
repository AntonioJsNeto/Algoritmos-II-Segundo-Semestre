package Pedido;

import java.text.DecimalFormat;

public class Pedido {
    private double valor;
    private double parcelas;
    private  double total;
    private  double juros;

    public Pedido(double a, int b){
        this.valor = a;
        this.parcelas = b;
        juros();
        total();
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getParcelas() {
        return parcelas;
    }

    public void setParcelas(double parcelas) {
        this.parcelas = parcelas;
    }

    public double getTotal() {
        return total;
    }

    public double getJuros() {
        return juros;
    }

    private void total(){
        DecimalFormat df = new DecimalFormat("0.00");
        this.total = valor * (1 + juros);
        if (parcelas > 1){
            double totalParcelas = total / parcelas;
            System.out.println("O valor total é de: " + df.format(total));
            System.out.println("O valor da parcela é de: " + df.format(totalParcelas));
        }
    }

    private void juros(){
        if (parcelas > 1){
            juros = 0.01;
            double jur = juros * Math.pow((1 + juros), parcelas);
        }else {
            System.out.println("SEM JUROS!");
        }
    }
}
