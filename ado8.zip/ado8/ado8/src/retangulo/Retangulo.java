package retangulo;

public class Retangulo {
    private double altura;
    private double base;


    public double getAltura() {
        return altura;
    }
    public Retangulo(double a, double b) {
        this.altura = a;
        this.base = b;
        this.perim();
        this.area();


    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    private double area;
    private double perimetro;

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    private void area(){
        this.area = this.altura * this.base;
    }

    private void perim(){
        this.perimetro = (this.altura *2) + (this.base*2);
    }
}
