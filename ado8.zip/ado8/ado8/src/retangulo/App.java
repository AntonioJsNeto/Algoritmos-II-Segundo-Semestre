package retangulo;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);

    public static void main(String [] args){

        System.out.println("INFORME A ALTURA: ");
        double per1 = sc.nextDouble();
        System.out.println("INFORME A BASE: ");
        double per2 = sc.nextDouble();

        Retangulo retangulo = new Retangulo(per1, per2);
        DecimalFormat df = new DecimalFormat("0.00");

        double area = retangulo.getArea();
        double perim = retangulo.getPerimetro();

        System.out.println("A area e: " + df.format(area));
        System.out.println("O perimetro e: " + df.format(perim));
    }
}
