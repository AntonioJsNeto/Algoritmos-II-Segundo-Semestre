package Pessoa;

import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);

    public static void main(String []args) {
        System.out.println("INFORME O NOME COMPLETO: ");
        String nomeCompleto = sc.nextLine();
        System.out.println("INFORME O ANO DE NASCIMENTO: ");
        int anoNasc = sc.nextInt();

        Pessoa pessoa = new Pessoa(nomeCompleto, anoNasc);

        String primeiro = pessoa.getPrimeiroNome();
        String ultimo = pessoa.getUltimoNome();
        int idade = pessoa.getIdade();

        System.out.println("A pessoa: " + primeiro + " " + ultimo + " tem " + idade + " anos.");
    }
}
