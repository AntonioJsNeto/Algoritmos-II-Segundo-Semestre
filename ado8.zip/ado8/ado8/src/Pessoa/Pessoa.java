package Pessoa;

public class Pessoa {
    private String nomeCompleto;
    private int anoNasc;
    private int idade;
    private String primeiroNome;
    private String ultimoNome;

    public Pessoa(String a, int b){
        this.nomeCompleto = a;
        this.anoNasc = b;
        this.idade();
        this.primeiroNome();
        this.ultimoNome();
    }

    public int getIdade() {
        return idade;
    }

    public String getPrimeiroNome() {
        return primeiroNome;
    }

    public String getUltimoNome() {
        return ultimoNome;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public int getAnoNasc() {
        return anoNasc;
    }

    public void setAnoNasc(int anoNasc) {
        this.anoNasc = anoNasc;
    }

    private void idade(){
        this.idade = 2023 - anoNasc;
    }

    private void primeiroNome(){
        String[] divisao = this.nomeCompleto.split(" ");

        if (divisao.length > 0) {
            this.primeiroNome = divisao [0];
        }
    }

    private void ultimoNome(){
        String[] divisao = this.nomeCompleto.split(" ");

        if (divisao.length > 0) {
            divisao [0]= divisao[divisao.length - 1];
            this.ultimoNome = divisao[0];
        }
    }
}
