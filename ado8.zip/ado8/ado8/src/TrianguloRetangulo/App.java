package TrianguloRetangulo;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("INFORME O CATETO OPOSTO: ");
        double per1 = sc.nextDouble();
        System.out.println("INFORME O CATETO ADJACENTE: ");
        double per2 = sc.nextDouble();

        TrianguloRetangulo tr = new TrianguloRetangulo(per1, per2);
        DecimalFormat df = new DecimalFormat("0.00");

        double area = tr.getArea();
        double perim = tr.getPerimetro();
        double hip = tr.getHipotenusa();

        System.out.println("A area e: " + df.format(area));
        System.out.println("O perimetro e: " + df.format(perim));
        System.out.println("A hipotenusa e: " + df.format(hip));
    }
}
