package TrianguloRetangulo;

public class TrianguloRetangulo {

    public TrianguloRetangulo(double a, double b) {
        this.catetoOposto = a;
        this.catetoAdjacente = b;
        this.hipotenusa();
        this.perimetro();
        this.area();
    }
    private double catetoOposto;
    private double catetoAdjacente;

    public double getCatetoOposto() {
        return catetoOposto;
    }

    public void setCatetoOposto(double catetoOposto) {
        this.catetoOposto = catetoOposto;
    }

    public double getCatetoAdjacente() {
        return catetoAdjacente;
    }

    public void setCatetoAdjascente(double catetoAdjacente) {
        this.catetoAdjacente = catetoAdjacente;
    }

    private double area;
    private double perimetro;
    private double hipotenusa;

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public double getHipotenusa() {
        return hipotenusa;
    }

    private void area(){
        this.area = (catetoAdjacente * catetoOposto) / 2;
    }

    private void perimetro(){
        this.perimetro = hipotenusa + catetoAdjacente + catetoOposto;
    }

    private void hipotenusa(){
        this.hipotenusa = Math.sqrt(Math.pow(catetoAdjacente,2) + Math.pow(catetoOposto,2));
    }
}
