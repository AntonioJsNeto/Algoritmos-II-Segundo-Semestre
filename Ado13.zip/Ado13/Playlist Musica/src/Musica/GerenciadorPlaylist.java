package Musica;


import java.util.Stack;

public class GerenciadorPlaylist {
    private Stack<Musica> itens = new Stack<>();

    public void adicionar(Musica musica) {
        itens.addElement(musica);
    }

    public void remover(int posicao) {
        itens.remove(posicao - 1);
    }

    public int buscar(String musica) {
        int indexMusica = 0;
        for (int i = 0; i < itens.size(); i++) {
            if (musica == itens.get(i).getNome()) {
                indexMusica = i;
            } else {
                indexMusica = 0;
            }
        }
        return indexMusica + 1;
    }

    public void exibirPlaylist(){
        System.out.println("\n\n---- Lista de Musica ----\n");
        for(int i = 0; i < this.itens.size(); i++){
            System.out.printf("%d. %s - %s\n", i+1, this.itens.get(i).getNome(), this.itens.get(i).getArtista());
        }
    }

    public Musica tocarProxima(){
        return itens.pop();
    }
}


