package Musica;

public class Musica {
    private String artista;
    private String nome;
    private String codYoutube;

    public String getCodYoutube() {
        return codYoutube;
    }

    public void setCodYoutube(String codYoutube) {
        this.codYoutube = codYoutube;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
