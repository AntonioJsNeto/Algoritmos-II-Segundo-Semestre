package Musica;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String [] args) throws IOException {
        Scanner ler = new Scanner(System.in);

        UI tela = new UI();
        tela.apresentarPrograma();

        GerenciadorPlaylist play = new GerenciadorPlaylist();

        int opcao;
        do {
            opcao = tela.menu();
            switch (opcao){
                case 1:
                    Musica musica = new Musica();
                    musica.setNome(tela.pedirTexto("Informe o nome da Musica: \n"));
                    musica.setArtista(tela.pedirTexto("Informa o Artista: \n"));
                    musica.setCodYoutube(tela.pedirTexto("Informe o código do youtube: "));
                    play.adicionar(musica);
                    tela.escrever(">> Musica adicionada!");
                    break;

                case 2:
                    Musica m = play.tocarProxima();
                    System.out.println("Tocando:" +
                            m.getNome() +"-" + m.getArtista());
                    Runtime.getRuntime().exec("cmd.exe /C start microsoft-edge:https://www.youtube.com/watch?v=" + m.getCodYoutube());
                    break;

                case 3:
                    String nomeMusica = "";
                   nomeMusica = tela.pedirTexto("\nInforme a musica que deseja buscar: \n");
                    int guardar =play.buscar(nomeMusica);
                    guardar += 1;
                    tela.escrever("A musica " + nomeMusica + " esta na posicao " + guardar + " a ser tocada");
                    break;

                case 4:
                    play.exibirPlaylist();
                    break;
            }
        }
        while (opcao != 0);
    }
}
