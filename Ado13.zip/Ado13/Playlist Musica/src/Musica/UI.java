package Musica;

    import java.util.*;

    public class UI {

        static Scanner ler = new Scanner(System.in);

        public void apresentarPrograma() {
            escrever("##### PROGRAMA LISTA DE MUSICAS #####\n");
        }

        public int menu() {
            escrever("\nO que deseja fazer?");
            escrever("1. Adicionar Musica");
            escrever("2. Próxima Musica");
            escrever("3. Buscar Musica");
            escrever("4. Exibir Musica");
            escrever("0. Sair");
            return ler.nextInt();
        }

        public void escrever(String msg, Object... values) {
            System.out.printf(msg+"\n", values);
        }

        public String pedirTexto(String msg, Object... values) {
            System.out.printf(msg, values);
            String valor = ler.next();
            return valor;
        }

        public int pedirInt(String msg, Object... values) {
            System.out.printf(msg, values);
            int valor = ler.nextInt();
            return valor;
        }

        public void pularLinha() {
            System.out.println();
        }
    }

