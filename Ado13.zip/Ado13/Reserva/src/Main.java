import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ControladorReserva cr =  new ControladorReserva();
        int opcao = 0;
        System.out.println("====Bem vindo===");
        while (true){

            System.out.println("O que deseja fazer ?");
            System.out.println("1-Adicionar Reserva");
            System.out.println("2-Chamar Próximo");
            System.out.println("3-Lista Reservas");
            System.out.println("0-Sair");
            opcao=Integer.parseInt(scan.next());
            switch (opcao){
                case 1:
                    Reserva r = new Reserva();
                    System.out.println("Nome:");
                    r.setResponsavel(scan.next());
                    System.out.println("Lugares");
                    r.setLugares(Integer.parseInt(scan.next()));
                    cr.adicionar(r);
                    break;
                case 2:
                    Reserva r1 = cr.proximo();
                    System.out.println("A próxima reserva a ser chamada é a de...");
                    System.out.println(r1.getResponsavel() + "-"+ r1.getLugares() + " lugares");
                    break;
                case 3:
                    cr.exibirReservas();
                    break;
                case 0:
                    System.exit(0);
                    break;
            }


        }

    }

}
