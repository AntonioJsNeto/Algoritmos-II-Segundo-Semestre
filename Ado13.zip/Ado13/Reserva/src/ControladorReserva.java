import java.util.ArrayDeque;
import java.util.Queue;

public class ControladorReserva {
    private Queue<Reserva> itens = new ArrayDeque<>();

    public void adicionar(Reserva reserva){

        itens.add(reserva);
    }

    public Reserva proximo(){

        return itens.poll();
    }

    public void exibirReservas(){
        System.out.println("Reservas Pendentes");
        for (Reserva m : itens){
            System.out.println(m.getResponsavel() + "-" + m.getLugares() + " lugares");
        }

    }
}
