

public class Main {

    public static void main(String []args){
        UL tela = new UL();

        tela.apresentarPrograma();

        Cliente cliente = new Cliente();
        cliente.setNome(tela.pedirTexto("Insira o nome do cliente: "));
        cliente.setEmail(tela.pedirTexto("Insira o email do cliente: "));

        tela.pularLinha();
        Item[] itens = new Item[tela.pedirInt("Quantos itens irá comprar: ")];

        for (int i = 0; i < itens.length; i++){
            Item inte = new Item();
            inte.setNome(tela.pedirTexto("Insira o nome do Item: "));
            tela.pularLinha();
            inte.setPreco(tela.pedirDouble("Insira o valor do item: "));

            itens[i] = inte;
            tela.pularLinha();
        }

        Compra compra = new Compra();
        compra.setCliente(cliente);
        compra.setCarrinho(itens);

        int formaDePag ;
        System.out.println("Qual a forma de pagamento ?"
                +"\n1 - Cartão de Crédito"
                +"\n2 - Pix"
                +"\n3 - Cartão de débito\n");
        formaDePag = (tela.pedirInt(""));

        switch (formaDePag){
            case 1 -> compra.setFormaPag("CRÉDITO");
            case 2 -> compra.setFormaPag("PIX");
            case 3 -> compra.setFormaPag("DÉBITO");
        }

        if (compra.getFormaPag().equals("CRÉDITO")){
            compra.setParcelas(tela.pedirInt("Insira a quantidade de parcelas: "));
        }else {
            compra.setParcelas(0);
        }
        compra.setCupom(tela.pedirTexto("Insira o cupom: "));

        LojaOnline lojaOnline = new LojaOnline();

        NotaFiscal notaFiscal = lojaOnline.efetuarCompra(compra);

        tela.escrever("Código da Nota:" + notaFiscal.getCodNota());
        tela.pularLinha();
        tela.escrever("Nome: " + notaFiscal.getCliente().getNome() + "\nEmail: " + notaFiscal.getCliente().getEmail());
        tela.pularLinha();
        tela.escrever("Item");
        tela.pularLinha();

        for(Item Itms : notaFiscal.getItem()){
            tela.escrever(Itms.getNome());
            tela.escrever( String.format("Preço: R$ %.2f", Itms.getPreco()));
            tela.pularLinha();
        }
        tela.escrever(String.format("Total da Compra: %.2f", notaFiscal.getTotal()));
        tela.pularLinha();
        if(notaFiscal.getValorParcelas() == notaFiscal.getTotal()){
            tela.escrever("Não há parcelas");
        }else {
            tela.escrever(String.format("Parcelas: %.2f", notaFiscal.getValorParcelas()));
        }

    }
}