
import java.util.*;

public class UL {
    static Scanner sc = new Scanner(System.in);

    public void apresentarPrograma() {

        escrever("##### PROGRAMA DA LOJA ONLINE #####\n");
    }

    public void escrever(String msg, Object... values) {

        System.out.printf(msg+"\n", values);
    }

    public double pedirDouble(String msg, Object... values) {
        System.out.printf(msg, values);
        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }

    public int pedirInt(String msg, Object... values) {
        System.out.printf(msg, values);
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }

    public String pedirTexto(String msg, Object... values) {
        System.out.printf(msg, values);
        String valor = sc.nextLine();
        return valor;
    }

    public void pularLinha() {

        System.out.println();
    }

    public void exibirCompra(NotaFiscal notaFiscal) {
        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("    COMPRA REALIZADA!");
        escrever("=========================");

        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("         ITENS");
        escrever("=========================");

        for (Item item : notaFiscal.getItem()) {
            escrever("%s  R$ %.2f ", item.getNome(), item.getPreco());
        }

        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("    TOTAL DA COMPRA");
        escrever("=========================");
        escrever("R$ %.2f", notaFiscal.getTotal());

        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("         DADOS DO CLIENTE");
        escrever("=========================");
        escrever("  Código: %d", notaFiscal.getCodNota());
        escrever(" Cliente: %s", notaFiscal.getCliente().getNome());
        escrever("Email: %s", notaFiscal.getCliente().getEmail());
        pularLinha();
        pularLinha();
        escrever("=========================");
        escrever("          FIM");
        escrever("=========================");
        pularLinha();
        pularLinha();
        pularLinha();
    }
}