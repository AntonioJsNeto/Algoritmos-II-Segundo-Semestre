public class NotaFiscal {

    public NotaFiscal(Cliente cliente, Item[] items, int codNota) {
        this.cliente = cliente;
        this.item = items;
        this.codNota = codNota;
    }
    private Cliente cliente;
    private Item[] item;

    private int codNota;
    private double total;
    private double valorParcelas;

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Item[] getItem() {
        return item;
    }

    public void setItem(Item[] item) {
        this.item = item;
    }

    public int getCodNota() {
        return codNota;
    }

    public void setCodNota(int codNota) {
        this.codNota = codNota;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getValorParcelas() {
        return valorParcelas;
    }

    public void setValorParcelas(double valorParcelas) {
        this.valorParcelas = valorParcelas;
    }
}
