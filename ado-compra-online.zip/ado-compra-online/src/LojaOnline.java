import java.lang.String;
import java.util.Objects;
import java.util.Random;
public class LojaOnline {

    public NotaFiscal efetuarCompra (Compra compra) {

        NotaFiscal notaFiscal = new NotaFiscal(compra.getCliente(), compra.getCarrinho(), gerarCodigo());

        notaFiscal.setTotal(calcularTotal(compra));

        notaFiscal.setValorParcelas(calcularParcela(notaFiscal.getTotal(), compra.getParcelas()));

        return notaFiscal;
    }

    private double calcularTotal(Compra compra){
        double total = 0;
        double debito = 0.05;
        double pix = 0.10;

        for(Item item : compra.getCarrinho()){
            total += item.getPreco();
        }
        double veri = verificarCupom(compra.getCupom());
        total = total - veri;

        if(compra.getFormaPag().equals("DÉBITO")){
            total -= total * debito;
        }else if (compra.getFormaPag().equals("PIX")){
            total -= total * pix;
        }else if (compra.getFormaPag().equals("CRÉDITO")) {
            total = total * Math.pow((1 + 0.03), compra.getParcelas());
        }

        return total;
    }

    private double calcularParcela(double total, int parcelas) {
        if (parcelas == 0){
            return total;
        }else {
            return total / parcelas;
        }
    }

    private double verificarCupom(String cupom) {
        double cem = 100;
        double duzentos = 200;
        double quinhentos = 500;
        if (("QUERO100".equals(cupom))) {
            return cem;
        } else if (("QUERO200".equals(cupom))) {
            return duzentos;
        } else if (("QUERO500".equals(cupom))) {
            return quinhentos;
        } else {
            System.out.println("INSIRA UM VALOR VÁLIDO!" + cupom);
            return 0;
        }
        }

    private int gerarCodigo (){
        int cod = (int) (Math.random()*999);
        return cod;
    }

}

