package Musica;

import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String [] args){
        Scanner ler = new Scanner(System.in);

        UI tela = new UI();
        tela.apresentarPrograma();

        GerenciadorPlaylist play = new GerenciadorPlaylist();

        int opcao;
        do {
            opcao = tela.menu();
            switch (opcao){
                case 1:
                    Musica musica = new Musica();
                    musica.setNome(tela.pedirTexto("Informe o nome da Musica: \n"));
                    musica.setArtista(tela.pedirTexto("Informa o Artista: \n"));
                    play.adicionar(musica);
                    tela.escrever(">> Musica adicionada!");
                    break;

                case 2:
                    play.remover(tela.pedirInt("\nInforme a posicao: \n"));
                    break;

                case 3:
                    String nomeMusica = "";
                   nomeMusica = tela.pedirTexto("\nInforme a musica que deseja buscar: \n");
                    int guardar =play.buscar(nomeMusica);
                    guardar += 1;
                    tela.escrever("A musica " + nomeMusica + " esta na posicao " + guardar + " a ser tocada");
                    break;

                case 4:
                    play.exibirPlaylist();
                    break;
            }
        }
        while (opcao != 0);
    }
}
