package Operacoes;

import contagem.Contagem;

import java.util.Scanner;

public class Main {
    public static void main(String args[]){
        Operacoes operacoes = new Operacoes();
        Scanner ler = new Scanner(System.in);
        System.out.println("Informe o numero:");
        int numero = ler.nextInt();
        System.out.println("Informe o divisor:");
        int divisor = ler.nextInt();

        System.out.println("Primos: " + operacoes.primo(numero, divisor));
    }
}
