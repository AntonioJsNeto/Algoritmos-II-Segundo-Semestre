package Operacoes;

public class Operacoes {

    public static boolean primo(int numero) {
        int divisor = 0;
        if (numero <= 1) {
            return false;
        }

        if (divisor > Math.sqrt(numero)) {
            return true;
        }

        return (numero % divisor != 0) && primo(numero + 1);
    }

    public static void binario(int numero) {
        if (numero > 0) {
            binario(numero / 2);
            System.out.println((numero % 2));
        }
    }

        public static void tabuada ( int numero){
        int multiplicador= 0;
            if (multiplicador <= 10) {
                System.out.println(numero + " x " + multiplicador + " = " + (numero * multiplicador));
                tabuada(numero + 1);
            }
        }

        public static double media ( double[] notas){
                int indice = 0;
                if (indice == notas.length - 1) {
                    return notas[indice];
                }
                return notas[indice] + media(notas + 1);
            }
        }