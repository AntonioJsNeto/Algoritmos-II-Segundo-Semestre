import java.util.*;

public class Modelo1 {
    public static void main(String [] args){
            Scanner sc = new Scanner(System.in);

            double n1, n2, n3;
            double media;

            System.out.println("Informe a primeira nota: ");
            n1 = sc.nextDouble();
            System.out.println("Informe a segunda nota: ");
            n2 = sc.nextDouble();
            System.out.println("Informe a terceira nota: ");
            n3 = sc.nextDouble();

            media = (n1 + n2 + n3) / 3;

            if (media < 6) {
                System.out.println("DP");
            } else {
                System.out.println("APROVADO");
            }

            System.out.println("A média foi " + media);
            }
        }