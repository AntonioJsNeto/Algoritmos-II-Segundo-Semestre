import java.util.*;

public class Boletim {
    static Scanner sc = new Scanner(System.in);
    public double calcularMedia(){
        double nota = Pergunta("Informe a nota: ");
        double media = (nota) / 3;
        return media;
    }

    public static double Pergunta(String msg){
        System.out.println(msg);
        double valor = sc.nextDouble();
        return valor;
    }

    public String verificarSituacao(double media){

        if(media >= 6){
            return "APROVADO!";
        }
        else{
            return "DP!";
        }
    }
}

