import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String [] args){
        Boletim result = new Boletim();

        double nota1 = result.Pergunta("Nota 01: ");
        double nota2 = result.Pergunta("Nota 02: ");
        double nota3 = result.Pergunta("Nota 03: ");

        double media = (nota1 + nota2 + nota3) / 3;
        String sit = result.verificarSituacao(media);

        System.out.println("Media : " + media + "\n");
        System.out.println("Situacao : " + sit);
    }
}