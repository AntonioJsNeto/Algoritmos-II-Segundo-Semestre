
package Escola;

import java.util.*;

public class Boletim {
    
    public double calcularMedia(NotasAluno notasAluno){
        double nota1 = notasAluno.getNota1();
        double nota2 = notasAluno.getNota2();
        double nota3 = notasAluno.getNota3();
        
        double media = (nota1 + nota2 + nota3) / 3;
        return media;
    } 
    
    public String verificarSituacao(double media){
        
        if(media >= 6){
            return "APROVADO!";
        }
        else{
            return "DP!";
        }
    }
}
