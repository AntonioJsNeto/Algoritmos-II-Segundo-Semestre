
package Escola;

import java.util.*;
public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String [] args){
        NotasAluno nota = new NotasAluno();
        Boletim result = new Boletim();
        
        System.out.println("Nota 01: ");
        nota.setNota1(sc.nextDouble());
        System.out.println("Nota 02: ");
        nota.setNota2(sc.nextDouble());
        System.out.println("Nota 03: ");
        nota.setNota3(sc.nextDouble());
        
        double media = result.calcularMedia(nota);
        String sit = result.verificarSituacao(media);
        
        System.out.println("Media : " + media + "\n");
        System.out.println("Situacao : " + sit);
    }
}
